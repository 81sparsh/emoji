const fs = require('fs');
const path = require('path');

export default function handler(req, res) {
  const directoryPath = path.join(process.cwd(), '/uploads');

  if (!fs.existsSync(directoryPath)) {
    return res.status(200).json([]);
  }

  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      res.status(500).json({ error: 'Error reading files' });
      return;
    }

    const images = files.map((file) => ({
      name: file,
      url: `/uploads/${file}`,
    }));

    res.status(200).json(images);
  });
}
