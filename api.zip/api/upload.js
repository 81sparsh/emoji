const formidable = require('formidable-serverless');
const fs = require('fs');
const path = require('path');

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const form = new formidable.IncomingForm();
    form.uploadDir = path.join(process.cwd(), '/uploads'); // Set upload directory
    form.keepExtensions = true;

    if (!fs.existsSync(form.uploadDir)) {
      fs.mkdirSync(form.uploadDir);
    }

    form.parse(req, (err, fields, files) => {
      if (err) {
        res.status(500).json({ error: 'Error parsing the file' });
        return;
      }

      const file = files.image;
      const filePath = path.join(form.uploadDir, file.name);
      fs.renameSync(file.path, filePath);

      res.status(200).json({ message: 'File uploaded successfully', filePath: `/uploads/${file.name}` });
    });
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}

export const config = {
  api: {
    bodyParser: false, // Disallow body parsing, since formidable takes care of it
  },
};
